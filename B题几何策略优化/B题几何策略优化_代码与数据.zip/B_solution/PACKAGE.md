本包为可复现的本地研究交付，六份官方加密日志仍未提供。

解压后进入本目录运行 python3 run_all.py；--full重跑固定独立/压力集。无需原工作目录，目录可改名。运行前安装requirements.txt所列依赖和C++17编译器。PDF重建另需XeLaTeX/ctex/Pandoc及字体。

为匿名交付，命令记录中的绝对用户路径已替换为PROJECT_ROOT/WORKSPACE_ROOT/USER_HOME；数值CSV和冻结模型源码未改动。原始路径记录保留在研究目录。以PACKAGE_HASHES.json校验包内文件，校验表不包含自身。
