# -*- coding: utf-8 -*-
"""基线策略: 螺旋粗测 -> 交会估计 -> 逼近清除 -> 垂直基线精测 -> 补测扇形扫描。

这是本环境的**基线**实现, 用来验证整套流程是否可用, 并给你们一个性能对照点。
请复制 `strategies/_template.py` 写你们自己的模型, 不要直接改这个文件
(这样 baseline 可以一直当作对照组)。

接入方式: 把文件放进 `strategies/` 目录, 类名即策略名:

    python -m mocksim.cli run --strategy BaselineSweep --runs 6

时序预算意识是这个问题的核心: 一次 /measure = 移动 + (可能 1 s 换频道) + 5 s 检测,
一次 /clear = 移动 + 3 s 或 5 s。20 分钟上限下检测次数是稀缺资源, 所以本策略
把预算分成四段:

1. 粗测: 沿覆盖圆域的螺旋线布稀疏探测点, 每点检测全部 20 个频道。
2. 逼近: 用最小二乘交会估计位置, 直接走到估计点 /clear
   (20 m 清除半径比 ±1° 示向度误差宽容得多)。
3. 精测: /clear 落空时沿垂直示向度方向平移一小段再测, 让交角接近 90°。
4. 补测: 仍未清除的频道, 在附近做一次小范围扇形扫描。

真值、干扰源个数、有效接收半径都不参与决策, 只用接口返回的
measure_result / svd_deg / clear_result。
"""

from __future__ import annotations

import math
import time

from mocksim.client import Estimator, RobotClient, StrategyResult

display_name = "基线螺旋交会策略"


class BaselineSweep:
    """参考基线: 先广域粗测建立方位线, 再交会逼近并清除。"""

    def __init__(self, *, coarse_points: int = 16, coarse_r_max_m: float = 1400.0,
                 min_ring_m: float = 380.0, refine_step_m: float = 35.0,
                 max_refine: int = 5, mopup_radius_m: float = 120.0,
                 mopup_arms: int = 6) -> None:
        self.coarse_points = coarse_points
        self.coarse_r_max_m = coarse_r_max_m
        self.min_ring_m = min_ring_m
        self.refine_step_m = refine_step_m
        self.max_refine = max_refine
        self.mopup_radius_m = mopup_radius_m
        self.mopup_arms = mopup_arms

    # -- 粗测路径 --------------------------------------------------------
    def probe_points(self) -> list[tuple[float, float]]:
        """从原点向外的螺旋探测点 (取前 coarse_points 个)。"""
        pts: list[tuple[float, float]] = [(0.0, 0.0)]
        step = self.min_ring_m
        while len(pts) < self.coarse_points and step <= self.coarse_r_max_m:
            for k in range(6):
                th = 2 * math.pi * k / 6 + step / 900.0
                pts.append((step * math.cos(th), step * math.sin(th)))
                if len(pts) >= self.coarse_points:
                    break
            step += self.min_ring_m
        return pts[:self.coarse_points]

    # -- 主循环 ----------------------------------------------------------
    def run(self, client: RobotClient, *, deadline_real_s: float | None = None,
            verbose: bool = True, virtual_budget_s: float | None = None
            ) -> StrategyResult:
        est = Estimator()
        result = StrategyResult()
        start = time.monotonic()
        pending: set[int] = set(range(1, 21))
        last_seen: dict[int, tuple[float, float]] = {}
        clock = [0.0]

        def out_of_time() -> bool:
            if deadline_real_s is not None and (time.monotonic() - start) > deadline_real_s:
                return True
            return virtual_budget_s is not None and clock[0] > virtual_budget_s

        def try_clear(x: float, y: float, ch: int) -> bool:
            result.attempts += 1
            resp = client.clear_checked(x, y, ch)
            clock[0] = RobotClient.virtual_time(resp, clock[0])
            if resp.get("clear_result") == "success":
                pending.discard(ch)
                result.cleared += 1
                if verbose:
                    print(f"    cleared ch{ch:>2} at ({x:8.1f},{y:8.1f}) "
                          f"t={clock[0]:.0f}s")
                return True
            return False

        def do_measure(x: float, y: float, ch: int) -> str:
            resp = client.measure_checked(x, y, ch)
            clock[0] = RobotClient.virtual_time(resp, clock[0])
            kind = resp["measure_result"]
            if kind == "direction":
                est.add(ch, x, y, float(resp["svd_deg"]), clock[0])
                last_seen[ch] = (x, y)
            elif kind == "near":
                last_seen[ch] = (x, y)
                try_clear(x, y, ch)          # 5 m 内信号过强, 直接光学清除
            return kind

        # ---- 1. 粗测 ---------------------------------------------------
        for (px, py) in self.probe_points():
            if out_of_time() or not pending:
                break
            for ch in sorted(pending):
                if out_of_time():
                    break
                do_measure(px, py, ch)

        # ---- 2/3. 逼近 · 清除 · 精测 -----------------------------------
        for ch in sorted(pending):
            if out_of_time():
                break
            for _ in range(self.max_refine):
                if out_of_time() or ch not in pending:
                    break
                e = est.estimate_all(ch)
                if e is not None and try_clear(e[0], e[1], ch):
                    break
                b = est.latest(ch)
                if b is None:
                    lx, ly = last_seen.get(ch, (0.0, 0.0))
                    if do_measure(lx, ly, ch) != "direction":
                        break
                    b = est.latest(ch)
                    if b is None:
                        break
                rad = math.radians(b.deg)
                bx, by = last_seen.get(ch, (b.x, b.y))
                do_measure(bx - self.refine_step_m * math.sin(rad),
                           by + self.refine_step_m * math.cos(rad), ch)

        # ---- 4. 补测 ---------------------------------------------------
        leftover = sorted(pending)
        if leftover and not out_of_time():
            cx, cy = last_seen.get(leftover[0], (0.0, 0.0))
            for ch in leftover:
                if out_of_time():
                    break
                for k in range(self.mopup_arms):
                    th = 2 * math.pi * k / self.mopup_arms
                    if do_measure(cx + self.mopup_radius_m * math.cos(th),
                                  cy + self.mopup_radius_m * math.sin(th), ch) == "direction":
                        e = est.estimate_all(ch)
                        if e is not None and try_clear(e[0], e[1], ch):
                            break

        if pending:
            result.note = f"未清除频道: {sorted(pending)}"
        if verbose:
            print(f"    策略自报: 清除 {result.cleared} 次尝试 {result.attempts} "
                  f"虚拟时刻 {clock[0]:.0f}s")
        return result
