# -*- coding: utf-8 -*-
"""策略模板 —— 复制这个文件改成你们自己的策略。

用法
----
1. 把本文件复制成 `strategies/你的策略名.py`
2. 改类名 (类名就是命令行的 --strategy 名字) 和 display_name
3. 在 run() 里实现你们的搜索/定位/清除逻辑
4. 运行:

       python -m mocksim.cli run --strategy 你的类名 --problem 3 --runs 6

可用接口 (只能用它, 不要读真值)
--------------------------------
    client.measure_checked(x, y, channel)  ->  {"measure_result": ..., "svd_deg": ..., "virtual_time_s": ...}
        measure_result: "direction" (有示向度) / "near" (<=5 m, 无示向度) / "no_signal"
    client.clear_checked(x, y, channel)    ->  {"clear_result": "success" | "no_target_in_range"}
    client.enter() / client.exit()         # 框架已经帮你调用了, 不用管

代价 (虚拟时间):
    移动 = 直线距离 / 5 m/s;  换频道 = 1 s;  检测 = 5 s;  清除 = 3 s (落空) 或 5 s (成功)
    总预算: 20 分钟程序运行时间 = 1200 s 现实时间 (虚拟时间上限 360000 s 通常不是瓶颈)

几何工具:
    from mocksim.client import Estimator              # 多方位线最小二乘交会
    est.add(channel, x, y, svd_deg)                   # 记录一条方位线
    est.estimate_all(channel) -> (x, y, rms) | None   # 交会求解
    est.baseline(channel)                             # 观测基线长度

注意事项:
    * /clear 不切换测向机频道, 只有成功的 /measure 会更新当前频道
    * no_signal 有三种可能: 该频道无未清除干扰源 / 超出有效接收半径 (1000~1500 m) /
      定向干扰源且当前位置在其覆盖范围外 (覆盖 = 定向方向两侧各 90°)
    * 定向干扰源在覆盖范围外测不到, 需要换个位置或换一侧再测
"""

from __future__ import annotations

import math

from mocksim.client import Estimator, RobotClient, StrategyResult

display_name = "我的策略"


class MyStrategy:
    """一句话说明你们的核心思想 (会显示在策略列表里)。"""

    def __init__(self, *, 参数名: float = 0.0) -> None:
        # 所有可调参数都写成关键字参数, 方便命令行 --strategy-kwargs 传参
        self.参数名 = 参数名

    def run(self, client: RobotClient, *, deadline_real_s: float | None = None,
            verbose: bool = True) -> StrategyResult:
        result = StrategyResult()
        est = Estimator()
        pending = set(range(1, 21))
        clock = 0.0

        # 例: 在原点扫一遍全部频道, 把测到的方位线记下来
        for ch in sorted(pending):
            resp = client.measure_checked(0.0, 0.0, ch)
            clock = RobotClient.virtual_time(resp, clock)
            if resp["measure_result"] == "direction":
                est.add(ch, 0.0, 0.0, float(resp["svd_deg"]), clock)

        # TODO: 你们的搜索/定位/清除算法
        #
        #   for ch in sorted(pending):
        #       e = est.estimate_all(ch)
        #       if e is None:
        #           continue
        #       x, y, rms = e
        #       resp = client.clear_checked(x, y, ch)
        #       clock = RobotClient.virtual_time(resp, clock)
        #       if resp["clear_result"] == "success":
        #           pending.discard(ch)
        #           result.cleared += 1

        if pending:
            result.note = f"未清除频道: {sorted(pending)}"
        if verbose:
            print(f"    策略自报: 清除 {result.cleared}, 虚拟时刻 {clock:.0f}s")
        return result


# 可选: 允许同一份文件里放多个策略类, 会在 --list-strategies 里分别列出
class MyStrategyVariant(MyStrategy):
    """同一思路的变体 (例如换搜索图案 / 换清除阈值)。"""

    def __init__(self, *, 参数名: float = 100.0) -> None:
        super().__init__(参数名=参数名)


_ = math  # 模板里可能暂时用不到 math, 保留导入避免 lint 报错
