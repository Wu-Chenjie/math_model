# -*- coding: utf-8 -*-
"""示例: 在基线基础上做参数变体 (演示如何继承与调参)。

这个文件同时是一个"可用的对照实验"示例:
保守变体减少粗测探测点以节省检测预算, 因此在时间紧时更早进入逼近阶段,
代价是初始方位线更少、部分频道可能需要靠精测阶段补。

    python -m mocksim.cli run --strategy ConservativeSweep --problem 3 --runs 6 --seeds 11 22 33 44 55 66
    python -m mocksim.cli compare --left BaselineSweep --right ConservativeSweep --seeds 11 22 33 44 55 66

也可以用命令行临时改参数 (不用改文件):

    python -m mocksim.cli run --strategy BaselineSweep --runs 6 --strategy-kwargs "{\"coarse_points\":20}"
"""

from __future__ import annotations

from strategies.baseline_sweep import BaselineSweep

display_name = "保守变体 (少探测点)"


class ConservativeSweep(BaselineSweep):
    """粗测只布 8 个探测点, 更快进入逼近阶段; 用更大 max_refine 兜住漏检。"""

    def __init__(self, *, coarse_points: int = 8, refine_step_m: float = 45.0,
                 max_refine: int = 8) -> None:
        super().__init__(coarse_points=coarse_points, refine_step_m=refine_step_m,
                         max_refine=max_refine)
