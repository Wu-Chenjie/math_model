# 26B 本地测试环境 · 快速上手（5 分钟）

> 一句话：这是一个**不消耗官方正式测试机会**的本地模拟器，用来反复调试你们的机器狗程序。
> 需要 Python 3.10+（你们机器上已有的 `F:\Python\python.exe` 是 3.14，够用）。

---

## 第 0 步：拿到代码

把整个 `26B-team` 目录放到任意位置（路径不要带空格更省心），例如 `D:\cumcm26b`。
不需要 pip install，只用 Python 标准库。

## 第 1 步：填参赛队号

打开 `config\team.json`，把 `team_id` 改成你们的参赛队号：

```json
{
  "team_id": "2026XXXXXXX",
  "team_check_enabled": true
}
```

> 本地演练用占位值也能跑（会提示 WARN）；但**正式测试必须用真实参赛队号**，
> 所以从一开始就填对，避免程序里写死。

## 第 2 步：自检

在目录里打开 PowerShell：

```powershell
python -m mocksim.cli doctor --full
```

看到 `[ OK ] 自检通过` 就可以了。它会检查 Python 版本、配置、端口、策略插件，
并跑一局端到端自测。**出错就把这一整屏截图发群里。**

## 第 3 步：跑一批演练

```powershell
# 问题3（全向源）
python -m mocksim.cli run --problem 3 --runs 6

# 问题4（全向 + 定向混合）
python -m mocksim.cli run --problem 4 --runs 6
```

输出在 `runs\p3\`（或 `p4`）：

| 文件 | 内容 |
|---|---|
| `table1-results.md` / `.csv` | 题目表1 格式的结果表（案例编码 / 清除个数 / 平均定位清除时间 / 程序运行时间） |
| `summary.json` | 汇总统计 + 每局真值与参数，便于 diff 对比 |
| `*.jsonl` | 每局**明文**请求/响应日志（调试用） |

终端还会打印**诊断**：哪些频道没清掉、干扰源真值在哪、检测/清除各多少次。

## 第 4 步：换成你们自己的策略

```powershell
copy strategies\_template.py strategies\my_strategy.py
```

1. 改类名（类名就是命令行里的策略名）
2. 在 `run()` 里写你们的搜索/定位/清除算法
3. 跑：

```powershell
python -m mocksim.cli strategies                                  # 确认被识别
python -m mocksim.cli run --strategy MyStrategy --runs 6 --seeds 11 22 33 44 55 66
```

**只能使用接口返回的信息**（`measure_result` / `svd_deg` / `clear_result`）。
自检会静态扫描策略文件，发现访问 `/debug/` 或直接读真值会直接报错，
因为那种程序在官方模拟器上必然失效。

## 第 5 步：A/B 对比两个策略

固定 seed 让两个策略跑**完全相同的案例**：

```powershell
python -m mocksim.cli compare --left BaselineSweep --right MyStrategy --seeds 11 22 33 44 55 66
```

结果写到 `runs\compare\compare.md`，逐局并列对比，适合直接贴进论文的对照实验。

---

## 常用命令速查

| 目的 | 命令 |
|---|---|
| 环境自检 | `python -m mocksim.cli doctor --full` |
| 完整协议自检（98 条断言） | `python -m mocksim.cli conformance` |
| 看有哪些策略 | `python -m mocksim.cli strategies` |
| 跑 6 局演练 | `python -m mocksim.cli run --problem 3 --runs 6` |
| 固定案例复现 | `python -m mocksim.cli run --runs 1 --seeds 20260913 --counts 12` |
| 模拟正式测试（不显示真值） | `python -m mocksim.cli run --mode formal --runs 3` |
| 临时改策略参数 | `--strategy-kwargs "{\"coarse_points\":20}"` |
| 起本地模拟器接自己的程序 | `python -m mocksim.cli serve --problem 3 --expose-debug` |
| 缩短现实时限快速调试 | `python -m mocksim.cli run --runs 1 --real-limit 60 --window 120` |

---

## 把你们自己的程序（非 Python）接进来

`python -m mocksim.cli serve --problem 3` 会在 `http://127.0.0.1:2026` 起一个
**与官方模拟器同端口、同协议**的服务，你们的程序只要把 `robot_id` 换成参赛队号即可直连。

* 请求格式、状态码、幂等规则都按 `附件2` 实现，直接用官方协议代码就能跑
* 接口在服务启动后就开放（不用等倒计时）
* 加 `--expose-debug` 可以 `GET /debug/truth` 看真值（**程序里不要调用**）
* **如果你们用 `requests`**：本机有系统代理，必须加
  `NO_PROXY=127.0.0.1,localhost` 或 `requests.post(url, proxies={"http": None})`，
  否则会得到 `502 Bad Gateway`

---

## 三条红线

1. **本地结果不能当正式成绩。** 题目要求支撑材料放的是官方模拟器导出的加密行为日志，
   正式测试机会每问只有 3 次，只能去官方模拟器跑。
2. **别偷看真值。** 本地环境给了真值和 `/debug/` 接口是为了**诊断**，
   程序用上它们，到了官方模拟器分数必然崩。
3. **尽早做正式测试。** 官方截止：北京时间 **2026-09-13 17:30** 之后无法新开测试，
   建议 **15:30 前**完成全部正式测试（避开网络拥堵）。

---

## 出问题怎么办

1. 先跑 `python -m mocksim.cli doctor --full`，把整屏输出发群里
2. 端口冲突 → `--port 2027`
3. `502 Bad Gateway` / `407` → 系统代理问题，见上面第 5 步
4. 想复现别人的某一局 → 用同一个 `--seeds`（案例由 seed 完全决定）
5. 详细的实现对照、常见坑清单、基线性能数据见 `README.md`
