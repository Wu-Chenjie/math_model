# 26B 本地测试环境

**2026 高教社杯 B 题《无线电干扰源的快速自动定位与清除》— 队内演练环境**

一套按公开协议规范实现的本地 mock 模拟器 + 演练框架，用来在**不消耗官方正式测试机会**的前提下
反复调试机器狗程序、做策略 A/B 对比、生成可复现的实验数据。

* 上手请看 **[QUICKSTART.md](QUICKSTART.md)**（5 分钟）
* 版本变更见 **[CHANGELOG.md](CHANGELOG.md)**
* 赛题与协议原文在 **[docs/](docs/)**（`B题全文.md`、`附件1.md`、`附件2.md`）

---

## 1. 边界声明（务必先读）

| | 说明 |
|---|---|
| ✅ 能做 | 无限次演练、给真值诊断、固定 seed 复现案例、A/B 对比、导出题目表1 格式结果表、明文行为日志、把你们自己的程序接到 `127.0.0.1:2026` |
| ❌ 不能做 | **替代官方正式测试**。题目要求放入支撑材料的是官方模拟器导出的加密行为日志；正式测试机会每问只有 3 次，只能在官方模拟器上用掉 |
| 🚫 明令禁止 | **程序里偷看真值**。本环境提供 `/debug/truth` 和真值诊断仅供人工排查；程序一旦依赖它们，到官方模拟器上必然失效。自检会静态扫描策略文件并直接报错 |

官方时间红线：北京时间 **2026-09-13 17:30** 之后无法新开演练/正式测试；
建议 **15:30 前**完成全部 3 次正式测试（避开网络拥堵）。

---

## 2. 为什么可以"照规范编"而不需要逆向官方程序

`附件2.docx`《模拟器通信接口说明及编程指南》本身就是一份完整规格书，已经写明了：

* 4 条指令的字段、类型、必填性、取值范围
* 全部 HTTP 状态码语义（200 / 400 / 404 / 405 / 409 / 413 / 415 / 429 / 500）
* `accepted=false` 的判定条件（未知字段、`arena_id` / `robot_id` 不匹配、状态机拒绝）
* 虚拟计时公式（移动 = 距离 ÷ 5 m·s⁻¹、换频道 1 s、检测 5 s、清除 3 s 或 5 s）
* 物理规则（有效接收半径 1000–1500 m、近距离阈值 5 m、清除半径 20 m、定向覆盖 ±90°）
* 误差模型（示向度误差 ∈ [-1°, 1°]，同点恒定、异点呈统计规律）
* 时限（25 min 窗口 / `/enter` 后 20 min / 虚拟世界 360000 s）

所以本环境是**规范的可执行实现**，不是官方程序的复制品；凡是规范没写死的地方
（随机分布、误差生成算法、频道分配），实现自行选择并在第 5 节逐条标注。

---

## 3. 目录结构

```
26B-team/
├─ run.ps1                  Windows 启动器 (不用记 python -m ...)
├─ mocksim/
│  ├─ arena.py              物理规则 / 虚拟计时 / 随机案例生成（附录1、附录2 的常数）
│  ├─ server.py             HTTP+JSON 接口层 + 测试生命周期 + 幂等 + 现实时间看门狗
│  ├─ client.py             机器狗客户端 + 方位几何工具（Estimator 最小二乘交会）
│  ├─ harness.py            批量演练、统计、表1 导出、明文日志、真值诊断、策略对比
│  ├─ discovery.py          策略插件发现 + "是否偷看真值"静态检查
│  ├─ doctor.py             环境自检
│  ├─ cli.py                统一命令行入口
│  ├─ config.py             分层配置
│  ├─ conformance.py        98 条协议一致性断言（逐条对标附件2 条款）
│  └─ version.py            版本信息
├─ strategies/              ← 你们的策略放这里，放进目录即被识别
│  ├─ _template.py          上手模板（以 _ 开头，不会被当成策略加载）
│  ├─ baseline_sweep.py     BaselineSweep  —— 基线策略
│  └─ example_conservative.py  ConservativeSweep —— 参数变体，演示 A/B 对比
├─ config/
│  ├─ team.json             ★ 填自己的参赛队号（不要提交到公共仓库）
│  └─ defaults.json         通用默认值
├─ docs/                    赛题与协议原文（从 PDF/DOCX 抽取，便于检索）
└─ scripts/build_release.ps1  打包发布脚本
```

---

## 4. 命令行

统一入口 `python -m mocksim.cli <子命令>`，也可用 `.\run.ps1 <子命令>`。

| 子命令 | 用途 |
|---|---|
| `doctor` | 环境自检（加 `--full` 含端到端自测，加 `--conformance` 含协议断言） |
| `strategies` | 列出 `strategies/` 里识别到的策略 |
| `conformance` | 98 条协议一致性断言 |
| `run` | 批量演练 → 统计 / 表1 / 明文日志 / 真值诊断 |
| `compare` | 同一批 seed 下对比两个策略 |
| `serve` | 起本地模拟器，接你们自己的（非 Python）程序 |

常用参数：

```
--problem 3|4          题目编号 (3 全向 / 4 全向+定向)
--runs N               跑几局
--mode practice|formal practice=演练(显示真值) / formal=按正式口径(不显示真值)
--seeds 11 22 33       固定案例 seed，完全可复现
--counts 12 14 16      固定干扰源个数
--strategy NAME        策略名（类名）
--strategy-kwargs '{"coarse_points":20}'   临时改策略参数，不用改文件
--real-limit 1200      现实时间上限秒（调试时压小，例如 60）
--window 1500          测试窗口秒
--out DIR              输出目录（默认 runs/p<问题>）
--quiet                少打印
```

### 例子

```powershell
# 环境自检
python -m mocksim.cli doctor --full

# 问题3 跑 6 局，输出到 runs/p3
python -m mocksim.cli run --problem 3 --runs 6

# 复现某一局（同 seed 同案例）
python -m mocksim.cli run --runs 1 --seeds 20260913 --counts 12

# 按正式口径跑 3 局（不显示真值），产出直接填题目表1
python -m mocksim.cli run --mode formal --runs 3

# 对比两个策略
python -m mocksim.cli compare --left BaselineSweep --right MyStrategy --seeds 11 22 33 44 55 66

# 起本地模拟器，开放调试接口
python -m mocksim.cli serve --problem 3 --expose-debug
```

### 输出文件

| 文件 | 内容 |
|---|---|
| `runs/p3/table1-results.md` / `.csv` | 题目表1 格式结果表 |
| `runs/p3/summary.json` | 汇总统计 + 每局参数与真值，便于 diff |
| `runs/p3/<策略>-<模式>-<序号>-<案例编码>.jsonl` | 每局明文请求/响应日志（调试用，**不要**当支撑材料） |
| `runs/compare/compare.md` | 策略对比表 |

---

## 5. 实现要点对照表（规范 → 代码）

| 规范条款 | 代码位置 |
|---|---|
| 附录2(6) 移动 5 m/s | `arena.SPEED_MPS`，`Session.measure/clear` 的 `move_s` |
| 附录2(4)(5)(8) 5 s 检测 / 1 s 换频道 / 3 s 或 5 s 清除 | `arena.MEASURE_COST_S` `SWITCH_COST_S` `CLEAR_*_COST_S` |
| 附录2(1) 示向度误差 ∈ [-1°,1°]，同点恒定 | `arena.svd_error_deg`（1 cm 网格量化 + blake2b，位置决定论） |
| 附录2(2) 有效接收半径 1000–1500 m | `arena.make_case` 采样 |
| 附录2(3) 定向覆盖 = 定向方向两侧各 90°（含） | `arena.angle_in_sector`（点积 ≥ 0，边界含） |
| 附录2(8) 清除半径 20 m，与覆盖角度无关 | `Session.clear`（只判距离，不判朝向） |
| 附录2(9) ≤5 m 且覆盖内 → `near`，不返回示向度 | `Session.measure` |
| 附件2 §4.1 微秒累计、最多 6 位小数 | `arena.quantise_time` |
| 附件2 §5.1 未知字段 → 200 `accepted=false` | `server.FIELDS` + `_guard_common` |
| 附件2 §5.1 Content-Type / charset / Content-Encoding → 415 | `Handler.do_POST` |
| 附件2 §5.1 重复键 / BOM / 嵌套>16 / 非对象 → 400 | `server.load_strict_json` |
| 附件2 §5.3 同 id 同内容重放、同 id 异内容 409、400 与 `accepted=false` 不占用 id | `MockSimulator._handle_locked` / `_commit` |
| 附件2 §5.3 接口未开放 → 直接关闭连接（无 JSON） | `Handler._drop`（`socket.shutdown`，不发响应） |
| 附件2 §4.5 25 min 窗口 + `/enter` 后 20 min，取较早者 | `LiveTest.remaining_real_s` / `real_expired` + 看门狗 |
| 附件2 §6.2 `remaining_real_duration_s` ∈ [0,1200] | `LiveTest.remaining_real_s` |
| 附件2 §10 完整计时示例 | `conformance.py` 第 10 节逐项数值复现（105 / 111 / 194 / 199 s） |

**规范未规定、本地自行选择的部分**（如需对齐官方行为请自行调整）：

1. 案例随机分布：位置在 1800 m 圆域内均匀采样，干扰源之间至少间隔 40 m；定向源个数取 1..n-1 均匀随机。
2. 误差生成算法：位置网格哈希 → U(−1, 1)。保证"同点恒定、异点近似独立均匀"，但具体数值与官方不同。
3. 频道分配：从 1..20 不放回抽样 n 个。
4. 错误响应额外带 `detail` 字段便于排查（规范只要求"至少包含"三个基础字段）。

---

## 6. 基线性能（对照点，不是最优解）

`BaselineSweep` 只是基线，用来验证整套环境可用。默认 20 min 现实上限下：

| 问题 | 平均清除比例 | 平均定位清除时间 |
|---|---|---|
| 问题 3（全向） | ≈ 0.96（4 局，3 局满分） | ≈ 943 s |
| 问题 4（全向 + 定向） | ≈ 0.85（6 局） | ≈ 1189 s |

建模时可复用的观察：

* **检测次数是唯一稀缺资源**：一次 `/measure` = 移动 + (1 s 换频道) + 5 s 检测；
  20 min 内大约只能做几百次检测，"每点扫多少频道"必须精打细算。
* 有效接收半径 1000–1500 m 意味着单点一次检测覆盖范围很大，但只对当前频道有效。
* 全向源两三条方位线即可交会到 20 m 内；定向源会出现 `no_signal`，
  必须"换个位置 / 换一侧再测"来消歧，这也是问题 4 清除率偏低的原因。
* 清除半径 20 m 远大于 ±1° 交会误差造成的偏差（基线 300 m 时约 5 m/°），
  因此"先粗交会、直接逼近清除"比"先把位置算得很准"更省时间。

自己跑对照：

```powershell
python -m mocksim.cli compare --left BaselineSweep --right ConservativeSweep --seeds 11 22 33 44 55 66
```

---

## 7. 常见坑（都已在本地环境踩过）

1. **系统代理**：本机若设了 `HTTP_PROXY` / `HTTPS_PROXY`，发往 `127.0.0.1:2026` 的请求会被转发出去，
   表现成 `502 Bad Gateway` 或 `407`，与模拟器无关。`RobotClient` 默认绕过系统代理；
   你们自己的程序若用 `requests`，请设 `NO_PROXY=127.0.0.1,localhost`
   或 `requests.post(url, proxies={"http": None, "https": None})`。
2. **`request_id` 复用**：每个新动作必须用新 id。同 id 配不同内容 → 409；
   只有"网络超时后重发一模一样的请求"才复用原 id。
3. **`accepted=false` 时 `virtual_time_s` 是 0**，不能当成当前虚拟时刻。
4. **不要只判断 HTTP 200**，必须同时判断 `accepted`；接口未开放时连接被直接关闭，没有 JSON 体。
5. **`/clear` 不切换测向机频道**，只有成功的 `/measure` 会更新当前频道。
6. **坐标越界**：一次 `/measure` 走到 2×10⁶ m 处会产生 4×10⁵ s 虚拟时间，直接触发虚拟世界超时结束本局。

---

## 8. 建议工作流

1. `python -m mocksim.cli doctor --full` —— 确认环境正常。
2. `python -m mocksim.cli run --problem 3 --runs 6` —— 用基线摸清量级。
3. 复制 `strategies/_template.py` 写自己的策略，固定 `--seeds` 做 A/B 对比（可复现）。
4. 看 `diagnosis()` 输出里的真值表：区分"没测到该频道"与"测到了但交会/逼近失败"，
   两者优化方向完全不同。
5. 策略稳定后**尽早**（建议 09-13 15:30 前）去官方模拟器完成 3 次正式测试并导出加密日志。

---

## 9. 打包发给队友

```powershell
.\scripts\build_release.ps1
```

生成 `dist\26B-team-v1.0.0.zip`，内容为干净目录树（剔除运行产物、真值日志、缓存、本机私有配置），
队友解压后：

1. 需要 Python 3.10+
2. `python -m mocksim.cli doctor --full`
3. 打开 `config/team.json` 填自己的参赛队号
4. 按 `QUICKSTART.md` 操作

> 发布包**不含任何人的参赛队号**，`config/team.json` 里是占位值 `TEAM0000`。
