# -*- coding: utf-8 -*-
"""生成 config/ 模板文件。

打包脚本用它来给暂存目录写配置模板 —— 由 Python 写盘可以保证:
* 输出是不带 BOM 的 UTF-8 (PowerShell 5.1 的 Set-Content -Encoding UTF8 会加 BOM,
  而 JSON 解析器不接受 BOM, 会让 `doctor` 直接报配置错误)
* 中文注释不会被按 ANSI 代码页读成乱码

用法:
    python scripts/make_config_templates.py <包根目录>
"""

from __future__ import annotations

import sys
from pathlib import Path


def main(argv: list[str]) -> int:
    if len(argv) != 2:
        print(__doc__)
        return 2
    root = Path(argv[1]).resolve()
    if not root.is_dir():
        print(f"错误: 目录不存在 {root}")
        return 2

    # 让 mocksim.config 把 ROOT 指到这个目录
    sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
    import os
    os.environ["MOCKSIM_PKG_ROOT"] = str(root)

    from mocksim import config as cfg
    if cfg.ROOT != root:
        print(f"错误: 目标目录不匹配 (ROOT={cfg.ROOT}, 期望 {root})")
        return 3

    created = cfg.ensure_config_files()
    for path in created:
        print(f"[created] {path}")
    if not created:
        print("[exists] config 模板已存在")

    team = cfg.TEAM_CONFIG
    if not team.exists():
        print(f"错误: 没有生成 {team}")
        return 4
    # 不带 BOM 校验
    if team.read_bytes()[:3] == b"\xef\xbb\xbf":
        print("错误: 生成的文件带了 BOM")
        return 5
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv))
