<#
.SYNOPSIS
    Build the release package for teammates: dist\26B-team-v<version>.zip

.DESCRIPTION
    Thin wrapper around scripts/build_release.py (all build logic lives in Python,
    so it is immune to Windows PowerShell 5.1 encoding/quoting issues).

.EXAMPLE
    .\scripts\build_release.ps1
    .\scripts\build_release.ps1 -NoZip
    .\scripts\build_release.ps1 -Out D:\share
#>
[CmdletBinding()]
param(
    [string]$Out,
    [switch]$NoZip,
    [switch]$IncludeSampleRuns,
    [switch]$SkipSelfCheck
)

$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path)

function Resolve-Python {
    $py = Get-Command py -ErrorAction SilentlyContinue
    if ($py) { return , @($py.Source, @('-3')) }
    $python = Get-Command python -ErrorAction SilentlyContinue
    if ($python) { return , @($python.Source, @()) }
    foreach ($p in @('F:\Python\python.exe',
                     "$env:LOCALAPPDATA\Programs\Python\Python313\python.exe")) {
        if (Test-Path -LiteralPath $p) { return , @($p, @()) }
    }
    throw 'Python not found. Install Python 3.10+ first.'
}

$py = Resolve-Python
$script = Join-Path $root 'scripts\build_release.py'
if (-not (Test-Path -LiteralPath $script)) { throw "missing: $script" }

$argList = @($script)
if ($Out) { $argList += @('--out', $Out) }
if ($NoZip) { $argList += '--no-zip' }
if ($IncludeSampleRuns) { $argList += '--include-sample-runs' }
if ($SkipSelfCheck) { $argList += '--skip-selfcheck' }

& $py[0] @($py[1]) @argList
exit $LASTEXITCODE
