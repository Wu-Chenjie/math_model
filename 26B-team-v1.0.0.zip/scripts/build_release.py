# -*- coding: utf-8 -*-
"""构建可发给队友的发布包。

把整个打包流程放在 Python 里, 而不是 PowerShell:

* Windows PowerShell 5.1 会把无 BOM 的 .ps1 按 ANSI 代码页读取, 内嵌中文会乱码;
* PS 5.1 向原生程序传参会破坏含括号/分号的参数, 内联 `python -c` 会静默失败;
* PS 5.1 的 `Set-Content -Encoding UTF8` 会写 BOM, 而 JSON 解析器不接受 BOM。

用 Python 写盘 + zipfile 打包可以完全绕开这三类坑。

用法:
    python scripts/build_release.py                 # 输出 dist/26B-team-v<版本>.zip
    python scripts/build_release.py --no-zip        # 只生成目录
    python scripts/build_release.py --out D:\\share  # 指定输出目录
"""

from __future__ import annotations

import argparse
import shutil
import subprocess
import sys
import zipfile
from pathlib import Path

#: 需要打进包里的顶层条目 (config/ 不在此列, 稍后由 mocksim.config 重新生成,
#: 这样可以保证包里永远是占位 team_id, 不会泄漏任何人的参赛队号)
INCLUDE = [
    "mocksim",
    "strategies",
    "scripts",
    "docs",
    "run.ps1",
    "README.md",
    "QUICKSTART.md",
    "CHANGELOG.md",
    ".gitignore",
]

EXCLUDE_DIRS = {"__pycache__", ".pytest_cache", ".venv", "venv", "runs", "dist"}
EXCLUDE_SUFFIXES = {".pyc", ".pyo", ".jsonl"}

#: 打包前必须不存在的路径片段 (真值日志 / 缓存)
FORBIDDEN_SUFFIXES = {".jsonl": "行为日志(含真值)"}
FORBIDDEN_DIRS = {"__pycache__": "python 缓存"}


def read_version(root: Path) -> str:
    text = (root / "mocksim" / "version.py").read_text(encoding="utf-8")
    for line in text.splitlines():
        if line.startswith("__version__"):
            return line.split("=", 1)[1].strip().strip('"').strip("'")
    raise SystemExit("无法从 mocksim/version.py 读取 __version__")


def copy_tree(src: Path, dst: Path) -> int:
    """递归复制目录, 跳过缓存与运行产物。返回复制的文件数。"""
    count = 0
    for item in sorted(src.iterdir()):
        if item.is_dir():
            if item.name in EXCLUDE_DIRS:
                continue
            dst.mkdir(parents=True, exist_ok=True)
            count += copy_tree(item, dst / item.name)
        else:
            if item.suffix in EXCLUDE_SUFFIXES:
                continue
            dst.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(item, dst)
            count += 1
    return count


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description="构建 26B 发布包")
    ap.add_argument("--out", default=None, help="输出目录 (默认 <仓库>/dist)")
    ap.add_argument("--no-zip", action="store_true", help="只生成目录, 不打包")
    ap.add_argument("--skip-selfcheck", action="store_true",
                    help="跳过端到端自检 (不建议)")
    ap.add_argument("--include-sample-runs", action="store_true",
                    help="附带样例结果表 (不含真值日志)")
    args = ap.parse_args(argv)

    root = Path(__file__).resolve().parent.parent
    version = read_version(root)
    pkg_name = f"26B-team-v{version}"
    out_root = Path(args.out).resolve() if args.out else root / "dist"
    stage = out_root / pkg_name

    print(f"== 构建 {pkg_name} ==")
    print(f"   仓库: {root}")
    print(f"   输出: {stage}")

    if stage.exists():
        shutil.rmtree(stage)
    stage.mkdir(parents=True)

    # ---- 1. 拷贝干净目录树 --------------------------------------------
    for entry in INCLUDE:
        src = root / entry
        if not src.exists():
            print(f"  [skip] 不存在: {entry}")
            continue
        dst = stage / entry
        if src.is_dir():
            dst.mkdir(parents=True, exist_ok=True)
            n = copy_tree(src, dst)
            print(f"  [ok]   {entry}/  ({n} 个文件)")
        else:
            shutil.copy2(src, dst)
            print(f"  [ok]   {entry}")
        sys.stdout.flush()

    # ---- 2. 生成 config 模板 (占位 team_id, 无 BOM) --------------------
    sys.path.insert(0, str(root / "scripts"))
    from make_config_templates import main as make_cfg  # noqa: PLC0415

    if make_cfg(["make_config_templates.py", str(stage)]) != 0:
        raise SystemExit("config 模板生成失败")
    print("  [ok]   config/ (占位 team_id, 无 BOM)")

    if args.include_sample_runs:
        sample = root / "runs" / "demo-p3"
        if sample.exists():
            dest = stage / "sample-runs"
            dest.mkdir(parents=True, exist_ok=True)
            for name in ("table1-results.md", "table1-results.csv", "summary.json"):
                p = sample / name
                if p.exists():
                    shutil.copy2(p, dest)
            print("  [ok]   sample-runs/ (仅结果表)")

    # ---- 3. 门禁: 暂存包必须通过自己的端到端自检 ----------------------
    if args.skip_selfcheck:
        print("  [skip] 端到端自检 (--skip-selfcheck)")
    else:
        print("  [..]   运行包内自检 doctor --full")
        sys.stdout.flush()
        proc = subprocess.run(
            [sys.executable, "-m", "mocksim.cli", "doctor", "--full"],
            cwd=str(stage), capture_output=True, text=True, encoding="utf-8",
            errors="replace",
        )
        if proc.returncode != 0:
            print(proc.stdout[-3000:])
            print(proc.stderr[-3000:], file=sys.stderr)
            raise SystemExit(f"包内自检失败 (exit {proc.returncode}), 已中止打包")
        print("  [ok]   包内自检通过")

    # ---- 4. 清掉自检产物 ----------------------------------------------
    runs = stage / "runs"
    if runs.exists():
        shutil.rmtree(runs)
        print("  [ok]   清理自检产物 runs/")
    caches = [p for p in stage.rglob("__pycache__") if p.is_dir()]
    for p in caches:
        shutil.rmtree(p)
    for p in stage.rglob("*.py[co]"):
        p.unlink()
    print(f"  [ok]   清理 python 缓存 ({len(caches)} 个目录)")

    # ---- 5. 泄漏门禁 ---------------------------------------------------
    problems: list[str] = []
    for suffix, label in FORBIDDEN_SUFFIXES.items():
        for p in stage.rglob(f"*{suffix}"):
            problems.append(f"{label}: {p.relative_to(stage)}")
    for dname, label in FORBIDDEN_DIRS.items():
        for p in stage.rglob(dname):
            problems.append(f"{label}: {p.relative_to(stage)}")
    team_cfg = stage / "config" / "team.json"
    if not team_cfg.exists():
        problems.append("缺少 config/team.json")
    else:
        raw = team_cfg.read_bytes()
        if raw[:3] == b"\xef\xbb\xbf":
            problems.append("config/team.json 带 BOM")
        text = raw.decode("utf-8")
        if '"TEAM0000"' not in text:
            problems.append("config/team.json 不是占位模板 (可能泄漏了真实参赛队号)")
    if problems:
        for p in problems:
            print(f"  [FAIL] {p}")
        raise SystemExit("拒绝打包: 检出泄漏或缺失文件")
    print("  [ok]   无行为日志 / 无缓存 / 占位 team_id")

    # ---- 6. 打包 -------------------------------------------------------
    if args.no_zip:
        print(f"\n目录已就绪: {stage}")
        return 0

    zip_path = out_root / f"{pkg_name}.zip"
    if zip_path.exists():
        zip_path.unlink()
    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as zf:
        for p in sorted(stage.rglob("*")):
            if p.is_file():
                zf.write(p, p.relative_to(stage))
    kb = zip_path.stat().st_size / 1024

    print(f"\n== 完成 ==")
    print(f"   目录:   {stage}")
    print(f"   压缩包: {zip_path}  ({kb:.1f} KB)")
    print("\n发给队友时附上:")
    print("   1) 需要 Python 3.10+")
    print("   2) 解压后先运行:  python -m mocksim.cli doctor --full")
    print("   3) 打开 config/team.json 填自己的参赛队号")
    print("   4) 细节见 QUICKSTART.md")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
