<#
.SYNOPSIS
    26B local test environment - Windows launcher (so you don't have to type python -m ...).

.DESCRIPTION
    This file is intentionally ASCII-only so it runs on Windows PowerShell 5.1 and
    PowerShell 7 with any system locale. All Chinese output comes from the Python CLI.

.EXAMPLE
    .\run.ps1 doctor                       # environment self-check
    .\run.ps1 run -Problem 3 -Runs 6       # 6 rehearsal runs
    .\run.ps1 run -Problem 4 -Formal       # formal-scoring mode (no ground truth)
    .\run.ps1 serve -Problem 3 -ExposeDebug
    .\run.ps1 strategies
    .\run.ps1 compare -Left BaselineSweep -Right MyStrategy -Seeds 11,22,33
    .\run.ps1 conformance
#>
[CmdletBinding()]
param(
    [Parameter(Position = 0)]
    [ValidateSet('doctor', 'run', 'serve', 'strategies', 'compare', 'conformance', 'help')]
    [string]$Command = 'help',

    [ValidateSet(3, 4)]
    [int]$Problem,

    [int]$Runs,

    [string]$Strategy,

    [int[]]$Seeds,

    [string]$Left,

    [string]$Right,

    [int]$Port,

    [string]$StrategyKwargs,

    [switch]$Full,

    [switch]$Formal,

    [switch]$ExposeDebug
)

$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location -LiteralPath $root

function Resolve-Python {
    $candidates = @()
    $py = Get-Command py -ErrorAction SilentlyContinue
    if ($py) { $candidates += , @($py.Source, @('-3')) }
    $python = Get-Command python -ErrorAction SilentlyContinue
    if ($python) { $candidates += , @($python.Source, @()) }
    foreach ($c in $candidates) {
        try {
            $null = & $c[0] @($c[1]) -c "import sys; print(sys.version_info[:2])" 2>$null
            if ($LASTEXITCODE -eq 0) { return , $c }
        }
        catch { }
    }
    foreach ($p in @('F:\Python\python.exe',
                     "$env:LOCALAPPDATA\Programs\Python\Python313\python.exe",
                     "$env:LOCALAPPDATA\Programs\Python\Python312\python.exe")) {
        if (Test-Path -LiteralPath $p) { return , @($p, @()) }
    }
    throw "Python not found. Please install Python 3.10+ and tick 'Add python.exe to PATH'."
}

$py = Resolve-Python
$exe = $py[0]
$pre = $py[1]

if ($Command -eq 'help') {
    Write-Host "26B local test environment - launcher" -ForegroundColor Cyan
    Write-Host ""
    Write-Host "  .\run.ps1 doctor [-Full]                     environment self-check"
    Write-Host "  .\run.ps1 run -Problem 3 -Runs 6 [-Strategy NAME] [-Seeds 11,22,33] [-Formal]"
    Write-Host "  .\run.ps1 serve -Problem 3 [-Port 2026] [-ExposeDebug]"
    Write-Host "  .\run.ps1 strategies                         list strategies in strategies\"
    Write-Host "  .\run.ps1 compare -Left A -Right B -Seeds 11,22,33"
    Write-Host "  .\run.ps1 conformance                        98 protocol assertions"
    Write-Host ""
    Write-Host "Tips:" -ForegroundColor DarkGray
    Write-Host "  * python -m mocksim.cli <command> works the same without this launcher"
    Write-Host "  * see QUICKSTART.md for the 5-minute guide"
    exit 0
}

$cliArgs = @('-m', 'mocksim.cli', $Command)
switch ($Command) {
    'doctor' {
        if ($Full) { $cliArgs += '--full' }
    }
    'run' {
        if ($Problem) { $cliArgs += @('--problem', $Problem) }
        if ($Runs) { $cliArgs += @('--runs', $Runs) }
        if ($Strategy) { $cliArgs += @('--strategy', $Strategy) }
        if ($Seeds) { $cliArgs += @('--seeds') + $Seeds }
        if ($Formal) { $cliArgs += @('--mode', 'formal') }
        if ($StrategyKwargs) { $cliArgs += @('--strategy-kwargs', $StrategyKwargs) }
    }
    'serve' {
        if ($Problem) { $cliArgs += @('--problem', $Problem) }
        if ($Port) { $cliArgs += @('--port', $Port) }
        if ($ExposeDebug) { $cliArgs += '--expose-debug' }
    }
    'compare' {
        if ($Left) { $cliArgs += @('--left', $Left) }
        if ($Right) { $cliArgs += @('--right', $Right) }
        if ($Seeds) { $cliArgs += @('--seeds') + $Seeds }
        if ($Problem) { $cliArgs += @('--problem', $Problem) }
    }
}

Write-Host "> $exe $($pre -join ' ') $($cliArgs -join ' ')" -ForegroundColor DarkGray
& $exe @pre @cliArgs
exit $LASTEXITCODE
